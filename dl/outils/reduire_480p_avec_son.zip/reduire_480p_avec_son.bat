@echo off
chcp 65001 >nul
title Reduire une video en 480p (avec le son)
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo ffmpeg n'est pas installe. Installation avec winget...
  winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
  echo.
  echo Installation terminee. FERME cette fenetre, puis glisse de nouveau tes videos sur ce fichier.
  pause
  exit /b
)
if "%~1"=="" (
  echo Glisse une ou plusieurs videos sur ce fichier .bat, avec la souris.
  pause
  exit /b
)
:boucle
if "%~1"=="" goto fin
echo.
echo Reduction de "%~nx1" ...
ffmpeg -hide_banner -loglevel error -y -i "%~1" -vf "scale=-2:480" -c:v libx264 -preset veryfast -crf 26 -c:a aac -b:a 128k -movflags +faststart "%~dpn1_480p_son.mp4"
if errorlevel 1 (
  echo ERREUR sur "%~nx1"
) else (
  echo OK : "%~n1_480p_son.mp4", dans le meme dossier que l original
)
shift
goto boucle
:fin
echo.
echo TERMINE
pause
